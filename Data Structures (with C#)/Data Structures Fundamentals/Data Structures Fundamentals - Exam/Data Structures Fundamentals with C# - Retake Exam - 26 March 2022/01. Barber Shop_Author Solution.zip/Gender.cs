﻿using System;
namespace BarberShop
{
    public enum Gender
    {
        MALE,
        FEMALE,
        OTHER
    }
}
